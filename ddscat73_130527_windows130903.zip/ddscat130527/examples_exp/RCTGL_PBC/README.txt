RCTGLPBC used to simulate infinite slab
  infinite slab , m=(1.50,0.02), thickness = 0.32um, wave=0.50um
  using 20x1x1 TUC (M,N)=(0,0)

a = 0.32um = slab thickness
b = X/20 = 0.016um
c = X/20 = 0.016um
V = 0.32*0.016*0.016 um^3
aeff = (3*V/4*pi)^{1/3} = 0.026942 um


s1 = 20	= X/d
s2 = 1	= Y/d
s3 = 1  = Z/d
s4 = 1  = P_y/d
s5 = 1  = P_z/d

wave = 0.5um
allowed (M,N)
M_max = int(L_y/wave)=int(0.016/0.5)=0

