problem parameters:
wave = 0.5um
h=0.10um
N_x=number of dipole layers: h=N_x*d

(4*pi/3)*a_eff^3 = N_x d^3 = N_x * (h/N_x)^3 = h^3/N_x^2

a_eff^3 = (3/4pi) h^3/N_x^2
a_eff = (3/4pi)^{1/3} * h / N_x^{2/3}

N_x = 10 -> a_eff = 0.0133650 um

N_x = 20 -> a_eff = 0.0084195 um   [d=0.005um]
