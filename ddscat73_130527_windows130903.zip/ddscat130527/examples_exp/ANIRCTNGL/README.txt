Problem: 0.1um x 0.2um x 0.2um rectangular block
         V = 0.004 um^3
	 aeff = (3V/4pi)^{1/3} = 0.098475um
         a1 along x_tf axis
	 m=1.33+0.01i for E || x_tf
	 m=1.33+0.01i for E || y_tf
         m=1.50+0.01i for E || z_tf
	 lambda = 0.5um
	 radiation incident along a_1 axis : target orientation Theta = 0
	 calculate for incident E polarized along y_lf and z_lf
